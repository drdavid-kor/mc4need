#!/bin/sh
set -eu
mkdir -p .private/backups
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
npx wrangler d1 export mc4need-db --remote --output ".private/backups/mc4need-$STAMP.sql"
chmod 600 ".private/backups/mc4need-$STAMP.sql"
printf 'Backup saved locally: .private/backups/mc4need-%s.sql\n' "$STAMP"
