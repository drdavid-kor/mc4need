# Mc4Need CLI + Skill

Sponsor a meal. Be part of it.

See INSTALL.md for installation and identity backup. Read skill/SKILL.md and skill/references/workflows.md before operating.

Source and verified limitations: https://github.com/drdavid-kor/mc4need
